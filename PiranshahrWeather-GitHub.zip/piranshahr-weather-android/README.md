# آب‌وهوای پیرانشهر

اپلیکیشن اندرویدی آب‌وهوای پیرانشهر با رابط HTML/CSS/JavaScript در WebView و لایهٔ بومی Kotlin و Jetpack Compose.

## ساخت APK با GitHub Actions

1. کل محتوای این پوشه را در ریشهٔ یک مخزن GitHub با شاخهٔ `main` قرار دهید.
2. از بخش **Actions** اجرای workflow با نام **Build Android APK** را بررسی کنید.
3. پس از موفقیت، فایل APK هم در بخش Artifacts همان اجرا و هم در Release با برچسب `latest` قرار می‌گیرد.

## ساخت محلی

- JDK 17
- Gradle 8.6
- Android SDK Platform 34 و Build Tools سازگار

سپس دستور `gradle assembleDebug` را اجرا کنید.

## ساختار

- `app/src/main/assets/weather.html`: رابط اصلی برنامه
- `app/src/main/java/com/example/weather/`: کد Kotlin و پل ارتباطی JavaScript/Android
- `.github/workflows/build-apk.yml`: ساخت خودکار APK و انتشار نسخهٔ آخر
