# Preserve JavascriptInterface methods for AndroidBridge
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keepclassmembers class com.example.weather.AndroidBridge {
    public *;
}